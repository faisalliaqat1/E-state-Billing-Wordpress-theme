<?php
/**
 * Template name: About page
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package E-State_Billing
 */

get_header();
?>
	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();?>
		<?php get_template_part('template-parts/banner-inner-archive');?>
        <section class="ftco-counter img ftco-section ftco-no-pt ftco-no-pb" id="about-section">
    	<div class="container">
    		<div class="row d-flex">
			    			<div class="col-md-6 col-lg-5 d-flex">
    				<div class="img d-flex align-self-stretch align-items-center" style="background-image:url(https://estatercm.com/wp-content/uploads/2024/04/about.jpg);">
    				</div>
    			</div>
    			<div class="col-md-6 col-lg-7 pl-lg-5 py-md-5">
    				<div class="">
	    				<div class="row justify-content-start pb-3">
			          <div class="col-md-12 heading-section ftco-animate p-4 p-lg-5 fadeInUp ftco-animated">
			            <h2 class="mb-4">About <span>Company </span></h2>
			            <p>Empire States Medical Billing Solutions LLC is a leading provider of comprehensive medical
billing services geared to the unique requirements of healthcare providers. Empire States
Medical Billing Solutions, with an emphasis on efficiency, accuracy, and compliance, provides a
variety of services to help healthcare providers of all sizes simplify their revenue cycle
processes. From electronic claims submission and payment posting to rejection management
and revenue analysis, their expert certified team guarantees that their clients receive timely
reimbursement and maximize their revenues. Empire States Medical Billing Solutions'
commitment to personalized service and cutting-edge technology enables healthcare
professionals to confidently and easily navigate the complexity of medical billing.
 </p>
			          </div>
			        </div>
		        </div>
	        </div>
        </div>
    	</div>
    </section>
    <?php get_template_part('template-parts/testimonial');?>
    <?php get_template_part('template-parts/quote');?>
   
    
      <?php 
		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
get_footer();

