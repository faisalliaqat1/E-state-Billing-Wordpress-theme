<?php
/**
 * Template name: Specialties page
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package E-State_Billing
 */

get_header();
?>
	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();?>
		<?php get_template_part('template-parts/banner-inner-archive');?>
		<section class="ftco-section ftco-no-pt ftco-no-pb ftco-services-2 bg-light" id="top-benifit">
			<div class="container">
        <div class="row d-flex">
	        <div class="col-md-12 py-5">
	        	<div class="py-lg-5">
		        	<div class="row justify-content-center pb-5">
			          <div class="col-md-12 heading-section ftco-animate fadeInUp ftco-animated">
			            <h2 class="mb-3">Let's Explore our Top Benefits!</h2>
						  <p>We recognize the necessity of selecting the right Revenue Cycle Management (RCM) system
for your practice is critical. At Empire States Medical Billing Solutions, we are committed to
aiding you in making an informed selection that meets your specific needs and objectives.</p>
<div class="list">
	<ul>
		<li>End to end Medical billing services</li>
		<li>RCM Team Support 24/7</li>
		<li>Thorough Practice Analysis</li>
		<li>HIPAA compliant</li>
		<li>Free Billing Software (Office Ally)</li>
		<li>96%+ First Time Pass Rate</li>
		<li>Free and secure cloud server access</li>
		<li>Reduced denials & rejections due to error free claims submission</li>
		<li>Increased practice revenue up to 30%</li>
		<li>15%+ Improvement in patient pay adherence</li>
		<li>No on boarding & signup charges</li>
		<li>Dedicated patient help desk</li>
	</ul>
</div>
			          </div>
			        </div>
					
			      </div>
		      </div>
		    </div>
			</div>
		</section>
        <section class="ftco-section ftco-no-pt ftco-no-pb" id="department-section1">
    	<div class="container-fluid px-0">
    		<div class="row no-gutters"> 
    			<div class="col-md-12">
    				<div class="row no-gutters department-row">
						<?php 
$dpt = get_field('dep-rep','option');
if($dpt):
    foreach($dpt as $row):
        $dpt_title = $row['dep-title'];
        $dpt_desc = $row['dep-desc'];
        ?>
        <!-- item start -->
        <div class="col-md-3 department-wrap p-4 ftco-animate">
            <div class="text p-2 text-center">
                <div class="icon">
                    <span class="flaticon-stethoscope"></span>
                </div>
                <h3><a href="#"><?php echo $dpt_title; ?></a></h3>
                <p><?php echo $dpt_desc; ?></p>
            </div>
        </div>
        <!-- item end -->
        <?php 
    endforeach; 
endif; ?>
                    </div>
    				</div>
    			</div>
    		</div>
    	</div>
    </section>
    <?php get_template_part('template-parts/testimonial');?>
    <?php get_template_part('template-parts/quote');?>
   
    
      <?php 
		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
get_footer();

