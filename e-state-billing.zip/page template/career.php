<?php
/**
 * Template name: Career page
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * E.g., it puts together the home page when no home.php file exists.
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package E-State_Billing
 */

get_header();
?>
	<main id="primary" class="site-main">

		<?php
		while ( have_posts() ) :
			the_post();?>
		<?php get_template_part('template-parts/banner-inner-archive');?>
        <section class="ftco-counter img ftco-section ftco-no-pt ftco-no-pb" id="about-section">
    	<div class="container">
    		<div class="row d-flex">
    			<div class="col-md-12 col-lg-12 py-md-5">
    				<div class="">
					<?php 
                    $career = get_field('career', 'option');
                    $cr_txt = $career['career_detail_'];
                    $cr_frm= $career['career_form_'];
                    ?>
	    				<div class="row justify-content-start pb-3">
			          <div class="col-md-12 heading-section ftco-animate p-4 p-lg-5 fadeInUp ftco-animated">
			            <p><?php echo $cr_txt; ?></p>
						<div class="career-form pt-3">
						<?php echo do_shortcode('[contact-form-7 id="'. $cr_frm .''); ?>
						</div>
			          </div>
			        </div>
		        </div>
	        </div>
        </div>
    	</div>
    </section>
	<?php get_template_part('template-parts/blog');?>
    <?php get_template_part('template-parts/testimonial');?>
	
   
    
      <?php 
		endwhile; // End of the loop.
		?>

	</main><!-- #main -->

<?php
get_footer();

