<?php
/**
 * Template part for displaying Testimonial
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Smart_Security
 */
?>
    <section class="ftco-section testimony-section img" style="background-image: url(<?php echo $url . 'images/bg_3.jpg';?>);">
    	<div class="overlay"></div>
      <div class="container">
        <div class="row justify-content-center pb-3">
          <div class="col-md-7 text-center heading-section heading-section-white ftco-animate">
          	<span class="subheading">Read testimonials</span>
            <h2 class="mb-4">Our Provider Says</h2>
          </div>
        </div>
        <div class="row ftco-animate justify-content-center">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel ftco-owl">
				<?php 
				$test_sec = get_field('test-rep','option');
				foreach($test_sec as $row):
					$title = $row['test-title'];
					$desg = $row['test-desg'];
					$desc = $row['test-desc'];
					$pf_img = $row['test-img'];
				?>
              <div class="item">
                <div class="testimony-wrap text-center py-4 pb-5">
                  <div class="user-img" style="background-image: url(<?php echo $pf_img['url'];?>)">
                    <span class="quote d-flex align-items-center justify-content-center">
                      <i class="icon-quote-left"></i>
                    </span>
                  </div>
                  <div class="text px-4">
                    <p class="mb-4"><?php echo $desc; ?></p>
                    <p class="name"><?php echo $title; ?></p>
                    <span class="position"><?php echo $desg; ?></span>
                  </div>
                </div>
              </div>
			  <?php endforeach;?>
            </div>
          </div>
        </div>
      </div>
    </section>