<?php
/**
 * Template part for displaying Testimonial
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Smart_Security
 */
?>
<?php
// Get the current post ID
$post_id = get_the_ID();

// Get the featured image URL for the current post
$featured_image_url = get_the_post_thumbnail_url($post_id);

?>
 <section class="hero-wrap hero-wrap-2" style="background-image: url(<?php echo esc_url($featured_image_url); ?>);" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-start">
          <div class="col-md-9 ftco-animate pb-4">
            <h1 class="mb-3 bread"><?php the_title(); ?></h1>
             <p class="breadcrumbs"><span class="mr-2"><a href="<?php echo home_url(); ?>">Home <i class="ion-ios-arrow-forward"></i></a></span> <span> <?php the_title(); ?></span></p>
          </div>
        </div>
      </div>
    </section>