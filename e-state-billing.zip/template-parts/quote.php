<?php
/**
 * Template part for displaying Testimonial
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Smart_Security
 */
?>
<?php 
$quote = get_field('free_quote','option');
    $name = $quote['title'];
    $xtt = $quote['text_'];
    $frm_shrtcode = $quote['form_shortcode'];
    $img_m = $quote['main_image_'];
?>
    <section class="ftco-section contact-section" id="contact-section">
      <div class="container">
      	<div class="row justify-content-center mb-5 pb-3">
          <div class="col-md-7 heading-section text-center ftco-animate">
            <h2 class="mb-4"><?php echo $name; ?></h2>
            <p><?php echo $xtt; ?></p>
          </div>
        </div>
        <div class="row d-flex contact-info mb-5">
		<?php 
                    $cntct = get_field('contact_sec', 'option');
                    $f_nbr = $cntct['first_naumber'];
                    $sec_nbr = $cntct['second_number'];
                    $email = $cntct['email'];
                    ?>
          <div class="col-md-6 col-lg-4 d-flex ftco-animate">
          	<div class="align-self-stretch box p-4 text-center bg-light">
          		<div class="icon d-flex align-items-center justify-content-center">
          			<span class="icon-map-signs"></span>
          		</div>
          		<h3 class="mb-4">Address</h3>
	            <p><?php echo $f_nbr; ?></p>
	          </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex ftco-animate">
          	<div class="align-self-stretch box p-4 text-center bg-light">
          		<div class="icon d-flex align-items-center justify-content-center">
          			<span class="icon-phone2"></span>
          		</div>
          		<h3 class="mb-4">Contact Number</h3>
	            <p><a href="tel:<?php echo $sec_nbr; ?>"><?php echo $sec_nbr; ?></a></p>
	          </div>
          </div>
          <div class="col-md-6 col-lg-4 d-flex ftco-animate">
          	<div class="align-self-stretch box p-4 text-center bg-light">
          		<div class="icon d-flex align-items-center justify-content-center">
          			<span class="icon-paper-plane"></span>
          		</div>
          		<h3 class="mb-4">Email Address</h3>
	            <p><a href="mailto:<?php echo $email; ?>"><?php echo $email; ?></a></p>
	          </div>
          </div>
        </div>
        <div class="row no-gutters block-9">
          <div class="col-md-6 order-md-last d-flex">
            <div class="bg-light p-5 contact-form">
			<?php echo do_shortcode('[contact-form-7 id="'. $frm_shrtcode .''); ?>
</div>
          
          </div>

          <div class="col-md-6 d-flex">
          	<div class="bg-whiteu">
			  <img class="img-fluid h-100" src="<?php echo $img_m['url']; ?>" style="object-fit: cover;" alt="">
			</div>
          </div>
        </div>
      </div>
    </section>