
		<section class="ftco-section" id="doctor-section">
			<div class="container-fluid px-5">
				<div class="row justify-content-center mb-5 pb-2">
          <div class="col-md-8 text-center heading-section ftco-animate">
            <h2 class="mb-4">Our Qualified Doctors</h2>
            <p>Separated they live in. A small river named Duden flows by their place and supplies it with the necessary regelialia. It is a paradisematic country</p>
          </div>
        </div>	
				<div class="row">
					<!-- Item start -->
					<?php 
					$doc = get_field('doc-rep','option');
					if($doc):
						foreach($doc as $row):
						$doc_title = $row['doc-title'];
						$doc_desg = $row['doc-desg'];
						$doc_img = $row['doc-img'];
						$doc_desc = $row['doc-desc'];
					?>
					<div class="col-md-6 col-lg-3 ftco-animate">
						<div class="staff">
							<div class="img-wrap d-flex align-items-stretch">
								<div class="img align-self-stretch" style="background-image: url(<?php echo $doc_img['url'];?>);"></div>
							</div>
							<div class="text pt-3 text-center">
								<h3 class="mb-2"><?php echo $doc_title;?></h3>
								<span class="position mb-2"><?php echo $doc_desg;?></span>
								<div class="faded">
									<p><?php echo $doc_desc;?></p>
									<ul class="ftco-social text-center">
		                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
		                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
		                <li class="ftco-animate"><a href="#"><span class="icon-google-plus"></span></a></li>
		                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
		              </ul>
		              <p><a href="#" class="btn btn-primary">Book now</a></p>
	              </div>
							</div>
						</div>
					</div>
					<?php endforeach; ?>
					<?php endif; ?>
					<!-- Item start -->
				</div>
			</div>
		</section>